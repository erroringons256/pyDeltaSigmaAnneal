#include <stdio.h>
#include "circBuf.h"

int main()
{
	printf("Testkompilation!\n");
	circBuf a;
	if (circBuf_init(&a, 8))
	{
		return 1;
	}
	double someBuffer[8] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0};
	circBuf_setBuffer(&a, someBuffer);
	circBuf_roll(&a, 4);
	circBuf_setElement(&a, 0, 5.5);
	circBuf_getBuffer(&a, someBuffer);
	for (size_t i = 0; i < 8; i++)
	{
		printf("%lf ", circBuf_getElement(&a, i));
	}
	printf("\n");
	return 0;
}