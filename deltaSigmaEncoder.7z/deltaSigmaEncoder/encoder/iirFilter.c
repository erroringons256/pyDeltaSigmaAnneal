#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "iirFilter.h"

char iirFilter_init(iirFilter* self, size_t xFilterLength, size_t yFilterLength)
{
	self->xFilter = malloc(sizeof(double) * xFilterLength);
	self->yFilter = malloc(sizeof(double) * yFilterLength);
	if (!self->xFilter ||
		!self->yFilter ||
		circBuf_init(&self->xState, xFilterLength) ||
		circBuf_init(&self->yState, &self->yState))
	{
		return 1;
	}
	self->xFilterLength = xFilterLength;
	self->yFilterLength = yFilterLength;
	return 0;
}

char iirFilterChain_init(iirFilterChain* self, size_t filterNum)
{
	self->filter = malloc(filterNum * sizeof(iirFilter*));
	if (!self->filter)
	{
		return 1;
	}
	self->filterNum = filterNum;
	return 0;
}

void iirFilter_setXFilter(iirFilter* self, double* xFilter)
{
	memcpy(self->xFilter, xFilter, sizeof(double) * self->xFilterLength);
}

void iirFilter_setYFilter(iirFilter* self, double* yFilter)
{
	memcpy(self->yFilter, yFilter, sizeof(double) * self->yFilterLength);
}