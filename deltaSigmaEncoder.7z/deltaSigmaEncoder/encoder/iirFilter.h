#ifndef DELTASIGMAENCODER
#define DELTASIGMAENCODER
#include "circBuf.h"
#include "stddef.h"

typedef struct iirFilter_struct
{
	double* xFilter;
	double* yFilter;
	circBuf xState;
	circBuf yState;
	size_t xFilterLength;
	size_t yFilterLength;
} iirFilter;

typedef struct iirFilterChain_struct
{
	double* input;
	iirFilter* filter;
	size_t filterNum;
} iirFilterChain;

#ifdef __cplusplus
extern "C"
#endif
char iirFilter_init(iirFilter*, size_t, size_t);

#ifdef __cplusplus
extern "C"
#endif
char iirFilterChain_init(iirFilterChain*, size_t);

#endif